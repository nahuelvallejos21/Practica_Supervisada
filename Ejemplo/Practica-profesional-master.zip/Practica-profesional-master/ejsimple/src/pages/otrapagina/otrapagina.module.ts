import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Otrapagina } from './otrapagina';

@NgModule({
  declarations: [
    Otrapagina,
  ],
  imports: [
    IonicPageModule.forChild(Otrapagina),
  ],
})
export class OtrapaginaModule {}
